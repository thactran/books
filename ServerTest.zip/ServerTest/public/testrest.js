var username;
var password;

function tryLogin(){
	username = document.getElementById("username").value;
	password = document.getElementById("password").value;
	document.getElementById("projectname").value = "";
	document.getElementById("contactname").value = "";
	document.getElementById("date").value = "";
	document.getElementById("phonenumber").value = "";
	document.getElementById("logindiv").style.display = "none";
	document.getElementById("infodiv").style.display = "inline-block";
}

function submitFunc(){
	
	var projectname = document.getElementById("projectname").value;
	var contactname = document.getElementById("contactname").value;
	var date = document.getElementById("date").value;
	var phonenumber = document.getElementById("phonenumber").value;
	
	var url = "http://servertest.bmxnp.appl.kp.org/submitdata";
	
	var http = new XMLHttpRequest();
	http.open("POST", url, true);
	http.setRequestHeader("Content-Type", "application/json");
	
	http.onreadystatechange = function() {
		if(http.readyState == 4) {
			if(http.status == 200){
				//alert("Successfully sent data!");
			}
			
			else{
				//alert("Error!");
			}
			
		}
		
		
	}
	var req = {'username':username, 
					'password':password, 
					'projectName': projectname,
					'contactName': contactname,
					'projectDate': date,
					'phoneNumber': phonenumber};
	
	http.send(JSON.stringify(req));
	document.getElementById("infodiv").style.display = "none";
	document.getElementById("confirmationdiv").style.display = "inline-block";
}

function submitAnotherFunc(){
	document.getElementById("projectname").value = "";
	document.getElementById("contactname").value = "";
	document.getElementById("date").value = "";
	document.getElementById("phonenumber").value = "";
	document.getElementById("confirmationdiv").style.display = "none";
	document.getElementById("infodiv").style.display = "inline-block";
}

function cancelFunc(){
	username = "";
	password = "";
	document.getElementById("username").value = "";
	document.getElementById("password").value = "";
	document.getElementById("infodiv").style.display = "none";
	document.getElementById("logindiv").style.display = "inline-block";
}

