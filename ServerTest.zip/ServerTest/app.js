/*eslint-env node*/

//------------------------------------------------------------------------------
// node.js starter application for Bluemix
//------------------------------------------------------------------------------

// This application uses express as its web server
// for more info, see: http://expressjs.com
var express = require('express');

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');

var request = require('request');
var bodyParser = require('body-parser');

// create a new express server
var app = express();

// serve the files out of ./public as our main files
app.use(express.static(__dirname + '/public'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: false
}));

app.post('/submitdata', function (req, res) {
	//console.log("ROUTING_TEST");
	//res.send('Hello from A!');
	//var url = "https://soa-bpm-dev.crdc.kp.org:11030/rest/bpm/wle/v1/process?bpdId=25.662a5f80-c20c-4a72-b3c2-606ed93ac910&processAppId=2066.5e1327db-4f18-494f-8115-34ce9f46eac8";
	
	//console.log(req.body.username);
	//console.log(req.body);
	//var authkey = window.btoa(req.query.username + ":" + req.query.password);
	
	var reqInfo = {'projectName': req.body.projectName,
						'contactName': req.body.contactName,
						'projectDate': req.body.projectDate,
						'phoneNumber': req.body.phoneNumber
	}
	
	var options = {
		method: 'POST',
		url: 'https://soa-bpm-dev.crdc.kp.org:11030/rest/bpm/wle/v1/process?bpdId=25.662a5f80-c20c-4a72-b3c2-606ed93ac910&processAppId=2066.5e1327db-4f18-494f-8115-34ce9f46eac8',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded',
			'Accept': 'application/json',
			'Authorization': 'Basic ' + new Buffer(req.body.username + ':' + req.body.password).toString('base64')
		},
		body: "action=start&params=" + JSON.stringify(reqInfo) + "&createTask=false&parts=all"
	}
	
	request(options, function (error, response, body) {
		if (!error && response.statusCode == 200) {
			// Print out the response body
			//console.log(body); //Test to see if logs header
			res.send(response);
		}
		
		else{
			console.log(error);
			console.log(response);
		}
	})
	
});

// get the app environment from Cloud Foundry
var appEnv = cfenv.getAppEnv();

// start server on the specified port and binding host
app.listen(appEnv.port, '0.0.0.0', function() {
  // print a message when the server starts listening
  console.log("server starting on " + appEnv.url);
});
